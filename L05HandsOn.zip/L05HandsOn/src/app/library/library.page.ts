import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-library',
  templateUrl: './library.page.html',
  styleUrls: ['./library.page.scss'],
})
export class LibraryPage implements OnInit {
  public books = [
    {
      title: "Lorem Ipsum",
      url: "/cover-one"
    },
    {
      title: "Bacon Ipsum",
      url:"/cover-two"
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
