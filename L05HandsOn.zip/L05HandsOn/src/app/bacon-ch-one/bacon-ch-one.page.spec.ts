import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaconChOnePage } from './bacon-ch-one.page';

describe('BaconChOnePage', () => {
  let component: BaconChOnePage;
  let fixture: ComponentFixture<BaconChOnePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaconChOnePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaconChOnePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
