import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bacon-ch-one',
  templateUrl: './bacon-ch-one.page.html',
  styleUrls: ['./bacon-ch-one.page.scss'],
})
export class BaconChOnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
