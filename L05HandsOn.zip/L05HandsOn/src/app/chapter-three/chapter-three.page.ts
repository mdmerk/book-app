import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter-three',
  templateUrl: './chapter-three.page.html',
  styleUrls: ['./chapter-three.page.scss'],
})
export class ChapterThreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
