import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bacon-ch-three',
  templateUrl: './bacon-ch-three.page.html',
  styleUrls: ['./bacon-ch-three.page.scss'],
})
export class BaconChThreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
