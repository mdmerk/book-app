import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaconChThreePage } from './bacon-ch-three.page';

describe('BaconChThreePage', () => {
  let component: BaconChThreePage;
  let fixture: ComponentFixture<BaconChThreePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaconChThreePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaconChThreePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
