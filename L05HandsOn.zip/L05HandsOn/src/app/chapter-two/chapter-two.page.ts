import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter-two',
  templateUrl: './chapter-two.page.html',
  styleUrls: ['./chapter-two.page.scss'],
})
export class ChapterTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
