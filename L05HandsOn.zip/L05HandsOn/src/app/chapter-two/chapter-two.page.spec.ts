import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChapterTwoPage } from './chapter-two.page';

describe('ChapterTwoPage', () => {
  let component: ChapterTwoPage;
  let fixture: ComponentFixture<ChapterTwoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChapterTwoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChapterTwoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
