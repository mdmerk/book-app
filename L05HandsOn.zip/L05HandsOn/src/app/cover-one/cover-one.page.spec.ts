import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoverOnePage } from './cover-one.page';

describe('CoverOnePage', () => {
  let component: CoverOnePage;
  let fixture: ComponentFixture<CoverOnePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoverOnePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoverOnePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
