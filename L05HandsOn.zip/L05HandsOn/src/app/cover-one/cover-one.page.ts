import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cover-one',
  templateUrl: './cover-one.page.html',
  styleUrls: ['./cover-one.page.scss'],
})
export class CoverOnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
