import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toc-two',
  templateUrl: './toc-two.page.html',
  styleUrls: ['./toc-two.page.scss'],
})
export class TocTwoPage implements OnInit {
  public chapters = [
    {
      title: "Chapter 1: Intro to Bacon",
      url: "/bacon-ch-one"
    },
    {
      title: "Chapter 2 History of Bacon",
      url: "/bacon-ch-two"
    },
    {
      title: "Chapter 3 Uses of Bacon",
      url: "/bacon-ch-three"
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
