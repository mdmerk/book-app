import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter-one',
  templateUrl: './chapter-one.page.html',
  styleUrls: ['./chapter-one.page.scss'],
})
export class ChapterOnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
