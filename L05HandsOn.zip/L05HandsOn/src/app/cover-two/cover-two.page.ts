import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cover-two',
  templateUrl: './cover-two.page.html',
  styleUrls: ['./cover-two.page.scss'],
})
export class CoverTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
