import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  { path: 'toc', loadChildren: './toc/toc.module#TocPageModule' },
  { path: 'chapter-one', loadChildren: './chapter-one/chapter-one.module#ChapterOnePageModule' },
  { path: 'chapter-two', loadChildren: './chapter-two/chapter-two.module#ChapterTwoPageModule' },
  { path: 'chapter-three', loadChildren: './chapter-three/chapter-three.module#ChapterThreePageModule' },
  { path: 'library', loadChildren: './library/library.module#LibraryPageModule' },
  { path: 'cover-one', loadChildren: './cover-one/cover-one.module#CoverOnePageModule' },
  { path: 'cover-two', loadChildren: './cover-two/cover-two.module#CoverTwoPageModule' },
  { path: 'toc-two', loadChildren: './toc-two/toc-two.module#TocTwoPageModule' },
  { path: 'bacon-ch-three', loadChildren: './bacon-ch-three/bacon-ch-three.module#BaconChThreePageModule' },
  { path: 'bacon-ch-two', loadChildren: './bacon-ch-two/bacon-ch-two.module#BaconChTwoPageModule' },
  { path: 'bacon-ch-one', loadChildren: './bacon-ch-one/bacon-ch-one.module#BaconChOnePageModule' }
  ];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
