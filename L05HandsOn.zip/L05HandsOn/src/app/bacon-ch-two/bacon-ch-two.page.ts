import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bacon-ch-two',
  templateUrl: './bacon-ch-two.page.html',
  styleUrls: ['./bacon-ch-two.page.scss'],
})
export class BaconChTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
