import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaconChTwoPage } from './bacon-ch-two.page';

describe('BaconChTwoPage', () => {
  let component: BaconChTwoPage;
  let fixture: ComponentFixture<BaconChTwoPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaconChTwoPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaconChTwoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
